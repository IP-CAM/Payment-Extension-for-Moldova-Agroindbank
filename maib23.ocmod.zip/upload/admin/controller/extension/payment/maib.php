<?php

require_once(DIR_SYSTEM . 'library/maib/vendor/autoload.php');

use Maib\MaibApi\MaibClient;

/**
 * MAIB payment extension.
 */
class ControllerExtensionPaymentMaib extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/maib');
		$data = $this->language->load('extension/payment/maib');
		
		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('setting/setting');
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			$this->model_setting_setting->editSetting('maib', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/extension', 'token='
				. $this->session->data['token'] . '&type=payment', true));
		}

		$data['breadcrumbs'] = $this->getBreadCrumbs();

		$data['_form'] = $this->getPostData();
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		$data['_error'] = $this->error;
		
		$data['maib_redirect_url']['Default test'] = MaibClient::MAIB_TEST_REDIRECT_URL;
		$data['maib_redirect_url']['Default live'] = MaibClient::MAIB_LIVE_REDIRECT_URL;
		if (defined('MAIB_REDIRECT_URL')) {
			$data['maib_redirect_url']['From config.php'] = MAIB_REDIRECT_URL;
		}
		else {
			$data['maib_redirect_url']['From config.php'] = '-<br>To override add your url to catalog and admin config.php, ex:' 
				 . '<br>define("MAIB_REDIRECT_URL", "https://maib.ecommerce.md:123/ecomm456/ClientHandler");';
		}
		
		$data['maib_merchant_url']['Default test'] = MaibClient::MAIB_TEST_BASE_URI;
		$data['maib_merchant_url']['Default live'] = MaibClient::MAIB_LIVE_BASE_URI;
		if (defined('MAIB_MERCHANT_URL')) {
			$data['maib_merchant_url']['From config.php'] = MAIB_MERCHANT_URL;
		}
		else {
			$data['maib_merchant_url']['From config.php'] = '-<br>To override add your url to catalog and admin config.php, ex:'
				 . '<br>define("MAIB_MERCHANT_URL", "https://maib.ecommerce.md:123/ecomm456/MerchantHandler");';
		}
		
    	$data['action'] = $this->url->link('extension/payment/maib', 'token='
    		. $this->session->data['token'], 'SSL');
		
		$data['cancel'] = $this->url->link('extension/extension', 'token='
			. $this->session->data['token'] . '&type=payment', true);
		$data['maib_shop_return_url'] = (defined('HTTPS_CATALOG') ? HTTPS_CATALOG : HTTP_CATALOG)
			. 'index.php?route=extension/payment/maib/return';
		$data['maib_cron_url'] = '59 23 * * * /usr/bin/wget -O - -q -t 1 '
			. (defined('HTTPS_CATALOG') ? HTTPS_CATALOG : HTTP_CATALOG)
			. 'index.php?route=extension/payment/maib/closeday 2>&1 >/dev/null';

		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$template = 'extension/payment/maib';
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($template, $data));	
	}

	private function validate() {
		$post_data = $this->request->post;

		if (!$this->user->hasPermission('modify', 'extension/payment/maib')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		$required = array('maib_private_key_file', 'maib_public_key_file');

		foreach ($required as $field) {
			if (empty($post_data[$field])) {
				$this->error[$field] = $this->language->get('error_empty_field');
			}
		}
		
		if (count($this->error)) {
			return false;
		}
		
		$pkey = (preg_match('/^\//', $post_data['maib_private_key_file']) ?
			'' : rtrim(DIR_SYSTEM, '/') . '/') . $post_data['maib_private_key_file'];
		if (empty($this->error['maib_private_key_file']) && !file_exists($pkey)) {
			$this->error['maib_private_key_file'] = $this->language->get('error_key_file_not_found');
		}
		
		$cert = (preg_match('/^\//', $post_data['maib_public_key_file']) ?
			'' : rtrim(DIR_SYSTEM, '/') . '/') . $post_data['maib_public_key_file'];
		if (empty($this->error['maib_public_key_file']) && !file_exists($cert)) {
			$this->error['maib_public_key_file'] = $this->language->get('error_key_file_not_found');
		}
		
		if (function_exists('openssl_x509_check_private_key')
			&& empty($this->error['maib_public_key_file'])
			&& empty($this->error['maib_private_key_file'])) {
			$cert_data = file_get_contents($cert);
			$key_data = array(
				file_get_contents($pkey),
				empty($post_data['maib_private_key_password']) ? null : $post_data['maib_private_key_password'],
			);
			if (false === openssl_x509_check_private_key($cert_data, $key_data)) {
				$this->error['maib_private_key_file'] = $this->language->get('error_key_file_not_match');
			}
		}

		return empty($this->error);
	}
	
	private function getBreadCrumbs() {
		$breadcrumbs = array();

		$breadcrumbs[] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token='
				. $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$breadcrumbs[] = array(
			'text' => $this->language->get('text_extensions'),
			'href' => $this->url->link('extension/extension', 'token='
				. $this->session->data['token'] . '&type=payment', true),
			'separator' => ' :: '
		);

		$breadcrumbs[] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/maib', 'token='
				. $this->session->data['token'], 'SSL'),      		
			'separator' => ' :: '
		);
		
		return $breadcrumbs;
	}
	
	private function getPostData() {
		$defautls = $this->getDefaults();
		foreach ($defautls as $key => $value) {
			$config = $this->config->get($key);
			if ($config !== null) {
				$defautls[$key] = $config;
			}
		}
		return array_merge($defautls, $this->request->post);
	}
	
	private function getDefaults() {
		return array(
			'maib_private_key_file' => '',
			'maib_private_key_password' => '',
			'maib_public_key_file' => '',
			'maib_mode' => 'test',
			'maib_method' => 'sms',
			'maib_total' => 0,
			'maib_order_status_id' => 1,
			'maib_order_pending_status_id' => 1,
			'maib_geo_zone_id' => '',
			'maib_status' => 1,
			'maib_sort_order' => 1,
			'maib_debug' => 0,
			'maib_last_closed_day' => '',
			'maib_fix_session_cookie' => 1,
			'maib_fix_language_cookie' => 1,
			'maib_fix_currency_cookie' => 1,
		);
	}

	public function install() {
        $this->load->model('extension/event');
        $this->model_extension_event->addEvent('maib', 'catalog/model/checkout/order/addOrderHistory/before', 'extension/payment/maib/addOrderHistoryBefore');
        $this->model_extension_event->addEvent('maib', 'catalog/model/checkout/order/addOrderHistory/after', 'extension/payment/maib/addOrderHistoryAfter');
		
	$this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "maib_transaction (
			transaction_id char(32) NOT NULL,
			order_id int NOT NULL,
			date_added char(20) NOT NULL,
			PRIMARY KEY (transaction_id))");
	}

	public function uninstall() {
        $this->load->model('extension/event');
        $this->model_extension_event->deleteEvent('maib');
		
	$this->db->query("DROP TABLE IF EXISTS " . DB_PREFIX . "maib_transaction");
	}

}