<?php
// Text
$_['text_title'] = 'Credit / Debit Card (via MAIB)';
$_['text_maib_error'] = 'Payment failed.';
$_['text_maib_pending'] = 'Payment still in pending state. Please check later or contact site administrator.';
$_['error_no_currency'] = 'Only following currency codes are supported: USD, EUR, MDL.';
$_['error_no_transaction_id'] = 'Unable to register payment transaction. Try again or use another payment method.';
$_['error_no_payment'] = 'Payment failed. Please try again or use another payment method.';
?>
