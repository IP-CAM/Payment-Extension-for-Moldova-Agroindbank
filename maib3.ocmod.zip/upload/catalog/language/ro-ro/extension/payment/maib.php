<?php
// Text
$_['text_title'] = 'Credit / Debit Card (prin MAIB)';
$_['text_maib_error'] = 'Plata a eșuat.';
$_['text_maib_pending'] = 'Starea plății e în continuare nedeterminată. Vă rugăm să contactați administratorul site-ului.';
$_['error_no_currency'] = 'Sunt permise doar următoarele valute: USD, EUR, MDL.';
$_['error_no_transaction_id'] = 'Nu poate fi înregistrată tranzacția pentru inițierea plății. Încercați din nou sau alegeți o altă metodă pentru plată.';
$_['error_no_payment'] = 'Plata a eșuat. Încercați din nou sau alegeți o altă metodă pentru plată.';
?>
